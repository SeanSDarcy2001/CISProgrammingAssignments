Aszewc1
sdarcy2

pa3.py              - program driver with main and calls to closest.py and testing.py
ciscode:
	__init__.py - initialization file
	frame.py    - contains frame class with frame manipulation methods
	pointer.py  - contains pivot calibration code (unused here)
	readers.py  - contains classes for reading input files
	writers.py  - contains classes for writing output files
	closest.py  - contains methods for computing closest point on triangle mesh
	testing.py  - contains testing and result validation suite for PA3
data:
	all data given to us for PA3
setup.py		   - required packages for "ciscode" starter
requirements.txt    - requirements for "ciscode" starter
tests:
	test_something.py - testing suite frame (unused for now)