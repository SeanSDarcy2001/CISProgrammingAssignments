def test_frame():
    assert True


def test_something_else():
    assert False
